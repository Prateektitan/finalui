import 'package:flutter/material.dart';
import 'package:news_app/Components/Constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

ThemeData light = ThemeData(
  scaffoldBackgroundColor: Colors.white,
  brightness: Brightness.light,
  accentColor: Constants.highlight_medium,
);

ThemeData dark = ThemeData(
  bottomNavigationBarTheme: BottomNavigationBarThemeData(
    backgroundColor: Constants.primary_dark,
    selectedItemColor: Colors.white,
  ),
  brightness: Brightness.dark,
  scaffoldBackgroundColor: Constants.primary_dark,
  appBarTheme: AppBarTheme(
    color: Constants.primary_dark,
  ),
  primaryColor: Constants.primary_light,
  primaryColorDark: Constants.primary_dark,
  accentColor: Constants.accent,
);

class ThemeNotifier extends ChangeNotifier{
  final String key = "theme";
  //SharedPreferences prefs;
  bool _darkTheme = true;

  bool get darkTheme => _darkTheme;

  ThemeNotifier(){
    _darkTheme = true;
  }

  toggleTheme(){
    _darkTheme != _darkTheme;
    notifyListeners();
  }



}