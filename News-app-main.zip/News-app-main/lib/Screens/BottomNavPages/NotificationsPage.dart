import 'package:flutter/material.dart';

class NotficationPage extends StatefulWidget {
  @override
  _NotficationPageState createState() => _NotficationPageState();
}

class _NotficationPageState extends State<NotficationPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
